Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/how-to-add-speech-recognition-to-the-website-javascript/

Instructions -

## Import attached posts.sql file in your database.
## Update database configuration in config.php file.
## Run the projects.
## Click on the Start button to take input from the Microphone.
## Says something for search e.g. PHP, jQuery, CodeIgniter, Bootstrap Modal, etc.
## Require to click the Start button for each new search.